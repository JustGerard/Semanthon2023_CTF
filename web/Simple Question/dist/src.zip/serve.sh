#!/bin/sh
node index.js